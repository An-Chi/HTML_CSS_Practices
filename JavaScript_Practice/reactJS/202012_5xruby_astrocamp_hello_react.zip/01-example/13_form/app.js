function App(){
  return (
    <div className="app">
      <FormInput />
      <FormRadio />
      <FormSelect />
      <FormCheckbox />
    </div>
  );
}

ReactDOM.render(
  <App />,
  document.getElementById('app')
);
