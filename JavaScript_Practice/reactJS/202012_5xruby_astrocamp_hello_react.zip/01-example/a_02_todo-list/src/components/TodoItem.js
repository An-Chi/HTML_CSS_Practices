import React from 'react';

export default function TodoItem(props) {
  const onClick = () => {
    props.onToggleItem(props.id);
  };
  let className = 'todo-item';
  if (props.done) {
    className += ' done';
  }
  return (
    <section data-name="TodoItem.js" className="style-2">
      <li className={className} onClick={onClick}>
        {props.children}
      </li>
    </section>
  );
}
