import React from 'react';
import Example from './Example';

function App() {
  return (
    <div className="app container">
      <Example />
    </div>
  );
}

export default App;
