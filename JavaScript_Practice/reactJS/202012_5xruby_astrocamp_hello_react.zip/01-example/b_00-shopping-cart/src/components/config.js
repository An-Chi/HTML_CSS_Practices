export const PRODUCTS = [
  {
    id: '1',
    img: 'images/cat001.jpg',
    title: '老大',
    price: 20,
  },
  {
    id: '2',
    img: 'images/cat002.jpg',
    title: '貝貝',
    price: 15,
  },
  {
    id: '3',
    img: 'images/cat003.jpg',
    title: '老虎',
    price: 10,
  },
  {
    id: '4',
    img: 'images/cat004.jpg',
    title: '胖胖',
    price: 8.5,
  },
  {
    id: '5',
    img: 'images/cat005.jpg',
    title: '小花',
    price: 9.99,
  },
  {
    id: '6',
    img: 'images/cat006.jpg',
    title: '黑臉',
    price: 12.5,
  }
];