
function FormInput(){
  const [name, setName] = React.useState('');
  /* // TODO
  const atChange = (e) => {
    setName(e.target.value);
  }
  return (
    <section>
      <h4>FormInput</h4>
      <p>name:{name}</p>
      <input 
        type="text"
        value={name}
        onChange={atChange} />
    </section>
  );
  // */
}